# Green Life — upgraded website

A polished static front-end concept for Green Life, based on the supplied Dragon's Den brief.

## Included
- AI-first hero with app/dashboard visual
- Body-scan experience mockup
- Smart nutrition, food scanner and AI Coach sections
- Progress dashboard / gamification-style visual
- Responsive mobile navigation
- Pricing: Free / Pro $10 / Premium $15
- FAQ accordion and food scanner demo modal
- Smooth reveal animations

## Important
This is a front-end prototype. The body scan, nutrition estimates and AI Coach are visual demos and are not real medical or fitness analysis. A production app would need a backend, validated models, authentication, payments, privacy/security controls and professionally reviewed guidance.

## Hosting
The site is static HTML/CSS/JS and can be deployed to GitHub Pages or another static host.
