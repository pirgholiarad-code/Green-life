const modal=document.getElementById('scanner');
function openScanner(){modal.classList.add('show');document.body.style.overflow='hidden'}
function closeScanner(){modal.classList.remove('show');document.body.style.overflow=''}
function simulateScan(){const r=document.getElementById('result');r.classList.add('show')}
modal?.addEventListener('click',e=>{if(e.target===modal)closeScanner()});
document.querySelectorAll('.faq-list button').forEach(btn=>btn.addEventListener('click',()=>{btn.classList.toggle('open')}));
document.querySelector('.menu')?.addEventListener('click',()=>{const nav=document.querySelector('.nav nav');nav.style.display=nav.style.display==='flex'?'none':'flex';if(nav.style.display==='flex'){nav.style.position='absolute';nav.style.top='70px';nav.style.left='18px';nav.style.right='18px';nav.style.flexDirection='column';nav.style.padding='18px';nav.style.background='#0c1a12';nav.style.border='1px solid rgba(255,255,255,.09)';nav.style.borderRadius='15px'}});
const reveal=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';reveal.unobserve(e.target)}}),{threshold:.08});
document.querySelectorAll('.feature,.price,.steps>div,.how-image,.dashboard,.metrics>div').forEach(el=>{el.style.opacity='0';el.style.transform='translateY(18px)';el.style.transition='opacity .6s ease,transform .6s ease';reveal.observe(el)});
